package com.example;
/*
Clase Pelicula que tenga los campos:
    titulo
    director
    género
    duración
    nacionalidad
    año
Debemos incluir los siguientes métodos:
    getter y setter para cada atributo
    método infoPelicula para mostrar toda la información de una pelicula formateada
 */
import jakarta.persistence.*;

@Entity
@Table(name = "filmoteca")

class Pelicula {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String titulo;
    private String director;
    private String genero;
    private Integer duracion;
    private String pais;
    private Integer anio;

    // Constructores
    public Pelicula() {}
   
    @Override
    public String toString() {
        return String.format("🎬 %s (%d) | Director: %s | Género: %s | Duración: %d min", 
                titulo, anio, director, genero, duracion);
    }
    //Defino los métodos get set
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    public String getNacionalidad() {
        return pais;
    }

    public void setNacionalidad(String nacionalidad) {
        this.pais = nacionalidad;
    }

    public int getYear() {
        return anio;
    }

    public void setYear(int year) {
        this.anio = year;
    }    

    //Defino el resto de métodos
     public void infoPelicula() { //Me muestra la información de la pelicula
        System.out.println("***********************************");
        System.out.println(titulo);
        System.out.println("***********************************");
        System.out.println("Director: "+director);
        System.out.println("Género: "+genero);
        System.out.println("Duración: "+duracion+" minutos");
        System.out.println("Nacionalidad: "+pais);
        System.out.println("Año de producción: "+anio);
     }

     //Método que transforma los datos del objeto en una cadena del tipo que usamos en el fichero de datos
     public String cadenaFichero() {
        return titulo+";"+director+";"+genero+";"+duracion+";"+pais+";"+anio;
     }
}
