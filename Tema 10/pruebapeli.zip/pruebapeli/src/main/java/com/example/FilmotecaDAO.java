package com.example;

import java.util.ArrayList;
import java.util.List;

//Clase para acceder a la BD
//Contendrá métodos que usen el EMF y devuelvan los datos en un formato que no dependa de la BD
import jakarta.persistence.*;

public class FilmotecaDAO {
    ConexionBD gestor = new ConexionBD();


    //Devuelve en un ArrayList todos los datos de la filmoteca
    public ArrayList<Pelicula> cargaDatosBruto() {
        //Conectamos a la BD y recogemos los datos
        EntityManager em = gestor.getEMF().createEntityManager();
        ArrayList<Pelicula> datos = new ArrayList<>();

        List<Pelicula> resultado = em.createQuery("FROM Pelicula", Pelicula.class).getResultList();


        datos = new ArrayList<>(resultado);

        em.close();
        return datos;
    }

    //Busca las películas del director, las carga en el ArrayList y devuelve el número de filas de la consulta
    public ArrayList<Pelicula> cargaDatosBusquedaDirector(String title) {
        //Conectamos a la BD y recogemos los datos
        EntityManager em = gestor.getEMF().createEntityManager();
        ArrayList<Pelicula> datos = new ArrayList<>();

        //Busco las peĺiculas cuyo director contenga lo que hay en la caja
        List<Pelicula> resultado = em.createQuery("FROM Pelicula WHERE LOWER(director) LIKE :director", 
            Pelicula.class)
            .setParameter("director", "%"+title.toLowerCase()+"%")
            .getResultList();

        datos = new ArrayList<>();

        datos = new ArrayList<>(resultado);

        em.close();
        return datos;
    }

    //Inserta una película en la BD
    public boolean insertaPelicula(Pelicula p) {
        //Conectamos a la BD y recogemos los datos
        EntityManager em = gestor.getEMF().createEntityManager();
        boolean exito = false;

        try {
            // 1. Iniciar la transacción (obligatorio para escribir)
            em.getTransaction().begin();
        
            // 2. Guardar el objeto
            em.persist(p);
        
            // 3. Confirmar los cambios (aquí se ejecuta el INSERT real)
            em.getTransaction().commit();
        
            exito = true; 
        } catch (Exception e) {
            // 4. Si algo falla, deshacemos los cambios (rollback)
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
        }            
        return exito;
    }

    //Borra la película cuyo título nos pasan
    public boolean borraPelicula(String tit) {
        //Conectamos a la BD y recogemos los datos
        EntityManager em = gestor.getEMF().createEntityManager();
        boolean exito = false;

        try {
            em.getTransaction().begin();

            // 1. Buscamos la película por título primero
            // Usamos .getSingleResult() si estamos seguros de que el título es único
            Pelicula p = em.createQuery("FROM Pelicula WHERE titulo = :titulo", Pelicula.class)
                      .setParameter("titulo", tit)
                      .getSingleResult();

            // 2. Si la encontramos (no saltó la excepción NoResultException), la eliminamos
            if (p != null) {
                em.remove(p);
                exito = true;
            }

            em.getTransaction().commit();
        } catch (Exception e) {
            if (em.getTransaction().isActive()) em.getTransaction().rollback();
            System.out.println("No se pudo eliminar: " + e.getMessage());
        } finally {
            em.close();
        }
        
        return exito;
    }

    //Actualiza el director de la película cuyo título nos pasan
    public boolean actualizaDirectorPelicula(String tit, String dir) {
        //Conectamos a la BD y recogemos los datos
        EntityManager em = gestor.getEMF().createEntityManager();
        boolean exito = false;
        try {
            em.getTransaction().begin();

            // 1. Buscamos la película por su título
            // Usamos .getSingleResult() asumiendo que el título es único
            Pelicula p = em.createQuery("FROM Pelicula WHERE titulo = :t", Pelicula.class)
                      .setParameter("t", tit)
                      .getSingleResult();

            // 2. Si la encuentra, modificamos el atributo usando el Setter de tu clase
            if (p != null) {
                p.setDirector(dir);
                // No hace falta llamar a em.persist() porque el objeto Peliula ya está gestionado  
                exito = true;
            }   

            em.getTransaction().commit();
        } catch (NoResultException e) {
            System.out.println("No se encontró ninguna película con el título: " + tit);
        } catch (Exception e) {
            if (em.getTransaction().isActive()) em.getTransaction().rollback();
            e.printStackTrace();
        } finally {
            em.close();
        }    
        return exito;
    }

    //Devuelve una pelicula aleatoria en el objeto Pelicula
    public Pelicula peliculaAleatoria() {
        Pelicula p = new Pelicula();
        EntityManager em = gestor.getEMF().createEntityManager();

        p = (Pelicula) em.createNativeQuery("SELECT * FROM filmoteca ORDER BY RAND() LIMIT 1",
                    Pelicula.class
            ).getSingleResult();

        return p;
    }
}
