package com.example;
//Clase para el acceso a la BD
//Contendrá métodos para crear la conexión y utilizarla desde cualquier ptra clase

import jakarta.persistence.*;


public class ConexionBD {
    private static final EntityManagerFactory emf = Persistence.createEntityManagerFactory("filmotecaPU");

    public EntityManagerFactory getEMF() {
        return emf;
    }
}
